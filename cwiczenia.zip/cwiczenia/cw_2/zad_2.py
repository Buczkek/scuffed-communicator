n = int(input("Podaj n: "))

fib = [print ([int((((1 + 5**0.5) / 2)**i - ((1 - 5**0.5) / 2)**i) / 5**0.5) for i in range(n)])]

print(fib)