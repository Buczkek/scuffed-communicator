zdanie = "Ala ma kota"

lista = [(s, len(s)) for s in zdanie.split()]

print(lista)
