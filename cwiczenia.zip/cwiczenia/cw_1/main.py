krotka = (1, [4.5], 'Test', True, None)
krotka[1][0] = 6
print(krotka)