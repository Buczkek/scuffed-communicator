alfabet = [chr(x) for x in range (ord('a'), ord('z')+1)]

for l in alfabet:
    print (l, l.upper())