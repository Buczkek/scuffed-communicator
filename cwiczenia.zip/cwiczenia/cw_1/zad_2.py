lista = input('Podaj trzy liczby po spacji: ').split(" ")
lista.sort()
print(lista[-1])