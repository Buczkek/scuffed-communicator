imie_nazwisko = input("Podaj imie i nazwisko: ")
print ('Witaj', imie_nazwisko)
l = int(input('Podaj wiek: '))
if (l <= 18):
    print("jesteś niepełnoletni")
else:
    print('jesteś pełnoletni')